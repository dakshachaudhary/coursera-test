function Loader() {
  return <div className="app-loader"></div>;
}

export default Loader;
